﻿// using System;
// using System.Collections.Generic;
// using System.Linq;
// using System.Text;

// namespace Advent.MMXX
// {
//     public class Day09 : IPuzzle
//     {
//         public string Name { get { return "2021-09";} }
 
//         public static int Part1(string input)
//         {
//             return 0;
//         }

//         public static int Part2(string input)
//         {
//             return 0;
//         }

//         public void Run(string input)
//         {
//             Console.WriteLine("- Pt1 - "+Part1(input));
//             Console.WriteLine("- Pt2 - "+Part2(input));
//         }
//     }
// }